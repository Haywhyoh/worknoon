<div class="glf-meta-box-wrap">
	<?php glf_get_template('templates/meta-box-section', array('list_section' => $list_section)) ?>
	<div class="glf-fields">
		<div class="glf-fields-wrapper">
