(function ($) {
    "use strict";
    jQuery(document).ready(function () {
        $(".civi-light-gallery").lightGallery({
            thumbnail: true,
            selector: ".lgbox",
        });
    });
})(jQuery);
